package com.googlepay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GooglePayAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
