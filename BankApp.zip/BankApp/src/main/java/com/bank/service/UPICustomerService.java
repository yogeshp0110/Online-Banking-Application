package com.bank.service;

public interface UPICustomerService {

	public boolean checkUserRegMob(String mobNumber);
}
