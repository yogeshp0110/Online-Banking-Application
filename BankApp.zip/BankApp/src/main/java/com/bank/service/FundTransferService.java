package com.bank.service;

import com.bank.dto.FundTransferRequestDto;

public interface FundTransferService {

	 public String fundTransfer(FundTransferRequestDto fundTransReq);
}
