package com.bank.service;



public interface UPIFundTransferService {

	
	

	public String fundTransferByMobile(double amount,String toMobileNumber, String fromMobileNumber);
}
